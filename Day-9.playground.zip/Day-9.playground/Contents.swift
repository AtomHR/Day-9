import UIKit

func a(f: Int) -> Void {
    f
}
print(a(f: 111))


func getUserData(for id: Int) -> String {
    if id == 1989 {
        return "Taylor Swift"
    } else {
        return "Anonymous"
    }
}

let data: (Int) -> String = getUserData
let user = data(1989)
print(user)

var e = getUserData

print(e(1980))
getUserData(for: 1989)

func nameOne(q: String, w: String, e: String) -> [String] {
    var i: [String] = []
    i.append(q)
    i.append(w)
    i.append(e)
    return i
}

nameOne(q: "wait", w: "1221", e: "asdfg")
var CopyNameOne = nameOne
CopyNameOne("vae", "qwefq", "wqedq")


let team = ["Gloria", "Suzanne", "Piper", "Tiffany", "Tasha"]
let sortedTeam = team.sorted()
print(sortedTeam)
print(team.sorted())


func captainFirstSorted(name1: String, name2: String) -> Bool {
    if name1 == "Piper" {
        return true
    } else if name2 == "Piper" {
        return false
    }

    return name1 < name2
}

let captainFirstTeam = team.sorted(by: captainFirstSorted)
//print(captainFirstTeam)

let captainFirstTeam1 = team.sorted(by: { (name1: String, name2: String) -> Bool in
    if name1 == "Suzanne" {
        return true
    } else if name2 == "Suzanne" {
        return false
    }

    return name1 < name2
})


var nameT = "as"

let nameT_copy = nameT.sorted {
    return $0 < $1
}

let nameT_copy2 = nameT.sorted { $0 > $1 }


var teams = ["Tyu", "twqo", "qww", "opq", "oow", "Tu", "Tee", "Teee"]
let teamser = teams.filter { $0.hasPrefix("o")}

var q = [1, 2, 3, 4, 5]
//let q1 = q.map { $0.sorted }

/*
 
 
 
 
 
 
 */

func fname() {
    print("oh!±")
}

fname()

let fnameCopy = fname
fnameCopy()

//let fnameCopy_2 = fname()
//fnameCopy_2


let hello = {
    print("Hello hell!")
}

hello()


let nameis = { (namet: String) -> Bool in
    if namet.count == 1 {
        "yep"
        return true
    } else {
        "NÖ"
        return false
    }
}

nameis("w")

func nn(re rt: Int) -> String {
    if rt == 1{
        return "1"
    } else {
        return "X"
    }
}

nn(re: 1)
var nn1: (Int) -> String = nn

nn1(0)


let pio = { () -> String in
    return "wq"
}

print(pio)

let t1eam = ["Gloria", "Suzanne", "Piper", "Tiffany", "Tasha"]

let c1aptainFirstTeam = t1eam.sorted { name1, name2 in
    if name1 == "Suzanne" {
        return true
    } else if name2 == "Suzanne" {
        return false
    }

    return name1 < name2
}


let numi = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

let numi_copy = numi.filter { $0.isMultiple(of: 3)}

print(numi_copy)


var apple = [2, 4, 6, 9, 11, 12, 10]

var apple_copy = apple.filter { $0.isMultiple(of: 2)}

apple.append(20)
apple_copy


let name_map = ["Gloria", "Suzanne", "Piper", "Tiffany", "Tasha"]

let name_map_copy = name_map.map {
    if $0 == "Gloria" {
        "1"
    } else if $0 == "Suzanne" {
        "2"
    } else if $0 == "Piper" {
        "3"
    } else if $0 == "Tiffany" {
        "4"
    } else {
        "oh... real? Tasha?"
    }
}

print(name_map_copy)
name_map


func makeArray(size: Int, using generator: () -> Int) -> [Int] {
    var numbers = [Int]()

    for _ in 0..<size {
        let newNumber = generator()
        numbers.append(newNumber)
    }

    return numbers
}

print(makeArray(size: 5, using: { Int.random(in: 0...1) }))


let make = makeArray(size: 5) { Int.random(in: 0...2)}


func random () -> Int {
    Int.random(in: 1...5)
}

let ran = random()

let random_1 = makeArray(size: 5, using: random)
let random_2 = makeArray(size: ran, using: random)


func hpo(ftu: () -> Void, sen: () -> Void, ruy: () -> Void) {
    print(1)
    ftu()
    print(2)
    sen()
    print(3)
    ruy()
    print(4)
}


hpo{
    print("one")
} sen: {
    print("ty")
} ruy: {
    print("fri")
}


func holdClass(name: String, lesson: () -> Void) {
    print("Welcome to \(name)!")
    lesson()
    print("Make sure your homework is done by next week.")
}
holdClass(name: "Philosophy 101") {
    print("All we are is dust in the wind, dude.")
}


func tuy(ru: String) {
    print(ru)
}

print(tuy(ru: "hi"))

var tuy_copy = tuy

print(tuy_copy("hii"))
