import UIKit

/*
 
 // Решение с временными переменными
 
let luckyNumbers = [7, 4, 38, 21, 16, 15, 12, 33, 31, 49]

var luckyNumber = luckyNumbers.filter { $0 % 2 != 0 } //либо { !$0.isMultiple(of: 2) }

var luckyNumber1 = luckyNumber.sorted { $0 < $1 }

var luckyNumber2 = luckyNumber1.map { "\($0) is a lucky number" } //вариант 1 (?)
print(luckyNumber2)

for i in luckyNumber1 {
    print("\(i) is a lucky number")
} //вариант 2 (?)

*/


/*
 
 //Решение без временной переменной, спагетти
 
let luckyNumbers = [7, 4, 38, 21, 16, 15, 12, 33, 31, 49]

let lucky = luckyNumbers.filter { $0 % 2 != 0 }.sorted { $0 < $1 }.map { "\($0) is a lucky number" }

for i in lucky {
    print("\(i)")
}

*/

 //Решение без временной переменной, без спагетти
let luckyNumbers = [7, 4, 38, 21, 16, 15, 12, 33, 31, 49]

let lucky = luckyNumbers
    .filter { $0 % 2 != 0 } // так же можно использовать { !$0.isMultiple(of: 2) }
    .sorted { $0 < $1 }
    .map { "\($0) is a lucky number" }

for i in lucky {
    print(i)
}
